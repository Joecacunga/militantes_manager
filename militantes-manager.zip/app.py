import streamlit as st
import pandas as pd
from utils import detectar_duplicados, exportar_excel

st.set_page_config(page_title="Gestão de Militantes", layout="wide")

st.title("📋 Sistema de Registo de Militantes")

# Upload de ficheiro Excel
uploaded_file = st.file_uploader("Carregar ficheiro Excel", type=["xlsx"])

if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.success("✅ Ficheiro carregado com sucesso!")

    # Mostrar os primeiros dados
    st.subheader("Pré-visualização dos dados")
    st.dataframe(df.head(50))

    # Detectar duplicados
    duplicados = detectar_duplicados(df)
    if not duplicados.empty:
        st.warning("⚠️ Foram encontrados registos duplicados!")
        st.dataframe(duplicados)
    else:
        st.info("Nenhum duplicado encontrado.")

    # Exportar
    if st.button("Exportar Excel limpo"):
        output = exportar_excel(df)
        st.download_button("⬇️ Baixar ficheiro tratado", output, "militantes_processados.xlsx")
