# 📋 Sistema de Registo de Militantes

Este é um sistema simples de gestão de militantes, desenvolvido em **Streamlit**.

## 🚀 Como usar
1. Carregar o ficheiro Excel no formato esperado (colunas: `Primeiro Nome`, `Último Nome`, `Telefone`, `Nº CAP`).
2. O sistema verifica duplicados e mostra alertas.
3. É possível exportar os dados tratados para um novo ficheiro Excel.

## 🌐 Deploy
Este projeto pode ser hospedado gratuitamente em [Streamlit Cloud](https://streamlit.io/cloud).

No deploy, garantir que o **Main file path** é:
```
app.py
```
